import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    return process.env.NODE_ENV === "development"
      ? [
          {
            source: "/api/:path*",
            destination: "http://localhost:3000/api/:path*",
          },
          {
            source: "/uploads/:path*",
            destination: "http://localhost:3000/uploads/:path*",
          },
          {
            source: "/health",
            destination: "http://localhost:3000/health",
          },
        ]
      : [];
  },
};

export default nextConfig;
