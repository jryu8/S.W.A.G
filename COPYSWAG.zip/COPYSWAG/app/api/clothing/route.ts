import { NextRequest, NextResponse } from "next/server";
import { writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";

// simple in-memory store
const items: any[] = [];

export async function GET(req: NextRequest) {
  return NextResponse.json({ items });
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("image") as File | null;

    if (!file) {
      return NextResponse.json(
        { success: false, error: "No image uploaded" },
        { status: 400 }
      );
    }

    const itemName = formData.get("itemName")?.toString() || "";
    const type = formData.get("type")?.toString() || "";
    const color = formData.get("color")?.toString() || "";
    const season = formData.get("season")?.toString() || "all";
    const tags = formData.get("tags")?.toString() || "";
    const favorite = formData.get("favorite") === "true";

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const ext = path.extname(file.name) || ".jpg";
    const filename = `${randomUUID()}${ext}`;
    const uploadPath = path.join(process.cwd(), "public", "uploads", filename);

    await writeFile(uploadPath, buffer);

    const image_url = `/uploads/${filename}`;

    const newItem = {
      item_id: randomUUID(),
      item_name: itemName,
      type,
      color,
      season,
      tags,
      image_url,
      is_favorite: favorite,
      created_at: new Date().toISOString(),
    };

    items.push(newItem);

    return NextResponse.json({ success: true, item: newItem });
  } catch (err) {
    console.error("Upload error:", err);
    return NextResponse.json(
      { success: false, error: "Upload failed on server" },
      { status: 500 }
    );
  }
}
