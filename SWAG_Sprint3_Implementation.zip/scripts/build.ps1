param([switch]$ApplyDb=$false,[switch]$StartServers=$false)
$ErrorActionPreference="Stop"
$repo=Split-Path -Parent $PSScriptRoot
$backend=Join-Path $repo "backend"
$venv=Join-Path $backend ".venv"
if(!(Test-Path $venv)){ python -m venv $venv }
& "$venv\Scripts\Activate.ps1"
if(Test-Path (Join-Path $backend "requirements.txt")){ pip install -r (Join-Path $backend "requirements.txt") }
if(Test-Path (Join-Path $backend ".env.example") -and -not (Test-Path (Join-Path $backend ".env"))){ Copy-Item (Join-Path $backend ".env.example") (Join-Path $backend ".env") }
if($ApplyDb){
  $schema=Join-Path $repo "db\schema_mysql.sql"
  $seed=Join-Path $repo "db\seed_mysql.sql"
  cmd /c "mysql -u root -p < ""$schema"""
  cmd /c "mysql -u root -p < ""$seed"""
}
if($StartServers){
  Start-Process -NoNewWindow -FilePath "cmd.exe" -ArgumentList "/c","scripts\run_backend.bat"
  Start-Process -NoNewWindow -FilePath "cmd.exe" -ArgumentList "/c","scripts\run_frontend_node.bat"
}
Write-Host "Build complete."