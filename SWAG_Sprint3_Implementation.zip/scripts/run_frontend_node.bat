@echo off
cd /d "%~dp0\..\frontend"
npx serve
