#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
REPO_ROOT="$( dirname "$SCRIPT_DIR" )"
BACKEND="$REPO_ROOT/backend"
mkdir -p "$BACKEND"
if [ ! -d "$BACKEND/.venv" ]; then python3 -m venv "$BACKEND/.venv"; fi
source "$BACKEND/.venv/bin/activate"
[ -f "$BACKEND/requirements.txt" ] && pip install -r "$BACKEND/requirements.txt" || true
[ -f "$BACKEND/.env" ] || { [ -f "$BACKEND/.env.example" ] && cp "$BACKEND/.env.example" "$BACKEND/.env" || true; }
if [ "${1:-}" = "--apply-db" ]; then
  mysql -u root -p < "$REPO_ROOT/db/schema_mysql.sql"
  mysql -u root -p < "$REPO_ROOT/db/seed_mysql.sql"
fi
if [ "${2:-}" = "--start-servers" ]; then
  ( cd "$BACKEND" && uvicorn main:app --host 0.0.0.0 --port 8000 --reload ) &
  ( cd "$REPO_ROOT/frontend" && python3 -m http.server 5173 ) &
fi
echo "Build complete."