# Backend (FastAPI)

⚠️ This package includes `Backend.rar`. Please extract it **here** (into this `backend/` folder) before running.

## .env
Copy `.env.example` to `.env` and edit values if needed.

## Run (Windows)
```
scripts\run_backend.bat
```

## Run (macOS/Linux)
```
make backend
make run-backend
```
