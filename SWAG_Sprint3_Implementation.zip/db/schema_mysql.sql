/* SWAG MySQL schema (portable, MySQL 5.7/8.0 & MariaDB) */
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS swag_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE swag_db;

DROP TABLE IF EXISTS outfit_history;
DROP TABLE IF EXISTS outfit_items;
DROP TABLE IF EXISTS outfits;
DROP TABLE IF EXISTS clothing_items;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  user_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(120)    NOT NULL,
  email         VARCHAR(191)    NOT NULL,
  password_hash VARCHAR(255)    NOT NULL,
  created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE categories (
  category_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100) NOT NULL,
  PRIMARY KEY (category_id),
  UNIQUE KEY uq_categories_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE clothing_items (
  item_id     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED NOT NULL,
  category_id INT    UNSIGNED NOT NULL,
  color       VARCHAR(40)     NULL,
  season      VARCHAR(40)     NULL,
  material    VARCHAR(60)     NULL,
  tags        VARCHAR(255)    NULL,
  image_url   VARCHAR(512)    NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (item_id),
  KEY idx_items_user     (user_id),
  KEY idx_items_category (category_id),
  CONSTRAINT fk_ci_user
    FOREIGN KEY (user_id)     REFERENCES users(user_id)       ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT fk_ci_category
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE outfits (
  outfit_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id         BIGINT UNSIGNED NOT NULL,
  outfit_name     VARCHAR(140)    NOT NULL,
  is_favorite     TINYINT(1)      NOT NULL DEFAULT 0,
  is_ai_generated TINYINT(1)      NOT NULL DEFAULT 0,
  created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (outfit_id),
  KEY idx_outfits_user (user_id),
  CONSTRAINT fk_outfits_user
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE outfit_items (
  outfit_id BIGINT UNSIGNED NOT NULL,
  item_id   BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (outfit_id, item_id),
  KEY idx_oi_item (item_id),
  CONSTRAINT fk_oi_outfit
    FOREIGN KEY (outfit_id) REFERENCES outfits(outfit_id) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT fk_oi_item
    FOREIGN KEY (item_id)   REFERENCES clothing_items(item_id) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE outfit_history (
  history_id        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id           BIGINT UNSIGNED NOT NULL,
  outfit_id         BIGINT UNSIGNED NULL,
  worn_date         DATE            NOT NULL,
  weather_condition VARCHAR(80)     NULL,
  temperature       DECIMAL(5,2)    NULL,
  created_at        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (history_id),
  KEY idx_hist_user (user_id),
  KEY idx_hist_outfit (outfit_id),
  KEY idx_hist_worndate (worn_date),
  CONSTRAINT fk_hist_user
    FOREIGN KEY (user_id)   REFERENCES users(user_id)   ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT fk_hist_outfit
    FOREIGN KEY (outfit_id) REFERENCES outfits(outfit_id) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
