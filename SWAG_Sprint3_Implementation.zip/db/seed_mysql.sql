USE swag_db;
INSERT INTO categories (name) VALUES
  ('Top'), ('Bottom'), ('Dress'), ('Shoes'),
  ('Outerwear'), ('Accessories'), ('Hat'), ('Bag')
ON DUPLICATE KEY UPDATE name = VALUES(name);
