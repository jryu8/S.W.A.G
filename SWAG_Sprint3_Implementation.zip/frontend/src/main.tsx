
import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './index.css'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { ClosetPage } from './pages/ClosetPage'
import { OutfitBuilderPage } from './pages/OutfitBuilderPage'
import { HistoryPage } from './pages/HistoryPage'
import { RecommendPage } from './pages/RecommendPage'
import { useAuthStore } from './store/auth'
import { Navbar } from './ui/Navbar'

function PrivateRoute({ children }: { children: JSX.Element }) {
  const token = useAuthStore(s => s.token)
  return token ? children : <Navigate to="/login" replace />
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/" element={<PrivateRoute><ClosetPage /></PrivateRoute>} />
          <Route path="/builder" element={<PrivateRoute><OutfitBuilderPage /></PrivateRoute>} />
          <Route path="/history" element={<PrivateRoute><HistoryPage /></PrivateRoute>} />
          <Route path="/recommend" element={<PrivateRoute><RecommendPage /></PrivateRoute>} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
