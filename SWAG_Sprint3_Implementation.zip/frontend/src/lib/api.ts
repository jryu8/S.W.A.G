
import axios from 'axios'

export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'

export const api = axios.create({
  baseURL: API_BASE,
})

export function setAuthToken(token: string | null) {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`
  } else {
    delete api.defaults.headers.common['Authorization']
  }
}

// Types matching a likely FastAPI schema
export type User = { id: number; email: string }
export type ClothingItem = {
  id: number; category: string; color?: string; size?: string;
  season?: string; image_url?: string; tags?: string[]
}
export type Outfit = { id: number; items: ClothingItem[]; created_at?: string; notes?: string }
export type Recommendation = { items: ClothingItem[]; reason?: string }

// Auth
export async function login(email: string, password: string) {
  // Assuming FastAPI OAuth2PasswordRequestForm at /auth/login
  const params = new URLSearchParams()
  params.append('username', email)
  params.append('password', password)
  const { data } = await api.post('/auth/login', params, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  })
  return data as { access_token: string; token_type: string }
}

export async function register(email: string, password: string) {
  const { data } = await api.post('/users/register', { email, password })
  return data as User
}

export async function me() {
  const { data } = await api.get('/users/me')
  return data as User
}

// Clothing
export async function listClothing(): Promise<ClothingItem[]> {
  const { data } = await api.get('/clothing')
  return data
}

export async function addClothing(payload: Omit<ClothingItem, 'id' | 'image_url'> & { image?: File | null }) {
  // If image upload is via multipart on /clothing
  const form = new FormData()
  form.append('category', payload.category)
  if (payload.color) form.append('color', payload.color)
  if (payload.size) form.append('size', payload.size)
  if (payload.season) form.append('season', payload.season)
  if (payload.tags) form.append('tags', JSON.stringify(payload.tags))
  if (payload.image) form.append('image', payload.image)
  const { data } = await api.post('/clothing', form)
  return data as ClothingItem
}

export async function deleteClothing(id: number) {
  await api.delete(`/clothing/${id}`)
}

// Outfits
export async function listOutfits(): Promise<Outfit[]> {
  const { data } = await api.get('/outfits')
  return data
}
export async function createOutfit(itemIds: number[], notes?: string) {
  const { data } = await api.post('/outfits', { item_ids: itemIds, notes })
  return data as Outfit
}
export async function deleteOutfit(id: number) {
  await api.delete(`/outfits/${id}`)
}

// Recommendations
export async function getRecommendations(params: { event?: string; season?: string }) {
  const { data } = await api.get('/recommendations', { params })
  return data as Recommendation[] | Recommendation
}
