
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'

export function Navbar() {
  const { token, setToken } = useAuthStore()
  const nav = useNavigate()
  const loc = useLocation()
  const active = (path: string) => loc.pathname === path ? 'font-semibold' : 'text-gray-600'

  return (
    <div className="bg-white border-b">
      <div className="container flex items-center justify-between py-3">
        <Link to="/" className="text-xl font-bold">Virtual Closet</Link>
        <nav className="flex gap-4">
          {token && <Link className={active('/')} to="/">Closet</Link>}
          {token && <Link className={active('/builder')} to="/builder">Builder</Link>}
          {token && <Link className={active('/history')} to="/history">History</Link>}
          {token && <Link className={active('/recommend')} to="/recommend">Recommendations</Link>}
          {!token && <Link className={active('/login')} to="/login">Login</Link>}
          {!token && <Link className={active('/register')} to="/register">Register</Link>}
          {token && <button className="btn" onClick={() => { setToken(null); nav('/login') }}>Logout</button>}
        </nav>
      </div>
    </div>
  )
}
