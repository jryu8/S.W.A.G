
import { useEffect, useState } from 'react'
import { addClothing, deleteClothing, listClothing, ClothingItem } from '@/lib/api'

export function ClosetPage() {
  const [items, setItems] = useState<ClothingItem[]>([])
  const [file, setFile] = useState<File | null>(null)
  const [form, setForm] = useState({ category: '', color: '', size: '', season: '', tags: '' })
  const [loading, setLoading] = useState(false)

  async function refresh() {
    setLoading(true)
    try {
      const data = await listClothing()
      setItems(data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { refresh() }, [])

  async function onAdd(e: React.FormEvent) {
    e.preventDefault()
    await addClothing({
      category: form.category,
      color: form.color || undefined,
      size: form.size || undefined,
      season: form.season || undefined,
      tags: form.tags ? form.tags.split(',').map(s=>s.trim()) : undefined,
      image: file
    })
    setForm({ category: '', color: '', size: '', season: '', tags: '' })
    setFile(null)
    await refresh()
  }

  return (
    <div className="space-y-6 mt-6">
      <div className="card">
        <h2 className="text-lg font-semibold mb-3">Add Clothing</h2>
        <form className="grid md:grid-cols-2 gap-3" onSubmit={onAdd}>
          <input className="input" placeholder="Category (e.g. Shirt)" value={form.category} onChange={e=>setForm({...form, category: e.target.value})} required />
          <input className="input" placeholder="Color" value={form.color} onChange={e=>setForm({...form, color: e.target.value})} />
          <input className="input" placeholder="Size" value={form.size} onChange={e=>setForm({...form, size: e.target.value})} />
          <input className="input" placeholder="Season" value={form.season} onChange={e=>setForm({...form, season: e.target.value})} />
          <input className="input" placeholder="Tags (comma separated)" value={form.tags} onChange={e=>setForm({...form, tags: e.target.value})} />
          <input className="input" type="file" onChange={e=>setFile(e.target.files?.[0] ?? null)} />
          <div className="md:col-span-2">
            <button className="btn btn-primary">Add</button>
          </div>
        </form>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Your Closet</h2>
          <button className="btn" onClick={refresh} disabled={loading}>{loading ? 'Loading...' : 'Refresh'}</button>
        </div>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map(i => (
            <div key={i.id} className="border rounded-xl overflow-hidden">
              {i.image_url ? <img src={i.image_url} className="w-full h-40 object-cover" /> : <div className="h-40 bg-gray-100 flex items-center justify-center text-sm text-gray-500">No image</div>}
              <div className="p-3">
                <div className="font-medium">{i.category}</div>
                <div className="text-sm text-gray-600">{[i.color, i.size, i.season].filter(Boolean).join(' · ')}</div>
                {i.tags && <div className="text-xs mt-1">{i.tags.join(', ')}</div>}
                <button className="btn mt-2" onClick={()=>deleteClothing(i.id).then(refresh)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
