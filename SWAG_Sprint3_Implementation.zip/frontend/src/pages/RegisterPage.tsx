
import { useState } from 'react'
import { register } from '@/lib/api'
import { useNavigate } from 'react-router-dom'

export function RegisterPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState<string | null>(null)
  const nav = useNavigate()

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setMessage(null)
    try {
      await register(email, password)
      setMessage('Registered! You can now log in.')
      setTimeout(()=>nav('/login'), 800)
    } catch (e: any) {
      setMessage(e?.response?.data?.detail ?? 'Registration failed')
    }
  }

  return (
    <div className="max-w-sm mx-auto mt-10 card">
      <h1 className="text-xl font-semibold mb-4">Create account</h1>
      <form className="space-y-3" onSubmit={onSubmit}>
        <div>
          <label className="label">Email</label>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        {message && <div className="text-sm">{message}</div>}
        <button className="btn btn-primary w-full">Sign up</button>
      </form>
    </div>
  )
}
