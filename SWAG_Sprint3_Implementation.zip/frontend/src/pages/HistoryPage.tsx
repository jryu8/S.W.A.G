
import { useEffect, useState } from 'react'
import { listOutfits, Outfit } from '@/lib/api'

export function HistoryPage() {
  const [outfits, setOutfits] = useState<Outfit[]>([])

  useEffect(() => {
    listOutfits().then(setOutfits)
  }, [])

  return (
    <div className="mt-6 card">
      <h2 className="text-lg font-semibold mb-3">Outfit History</h2>
      <div className="space-y-3">
        {outfits.map(o => (
          <div key={o.id} className="border rounded-xl overflow-hidden">
            <div className="p-3 flex items-center justify-between">
              <div>
                <div className="font-medium">Outfit #{o.id}</div>
                <div className="text-sm text-gray-600">{o.created_at ? new Date(o.created_at).toLocaleString() : ''}</div>
                {o.notes && <div className="text-sm mt-1">{o.notes}</div>}
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-3">
              {o.items?.map(i => (
                <div key={i.id} className="border rounded-xl">
                  {i.image_url ? <img src={i.image_url} className="w-full h-24 object-cover" /> : <div className="h-24 bg-gray-100" />}
                  <div className="p-2 text-sm">{i.category}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
        {outfits.length === 0 && <div className="text-sm text-gray-600">No outfits yet.</div>}
      </div>
    </div>
  )
}
