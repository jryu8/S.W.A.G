
import { useEffect, useState } from 'react'
import { ClothingItem, createOutfit, listClothing } from '@/lib/api'

export function OutfitBuilderPage() {
  const [items, setItems] = useState<ClothingItem[]>([])
  const [selected, setSelected] = useState<number[]>([])
  const [notes, setNotes] = useState('')

  useEffect(() => {
    listClothing().then(setItems)
  }, [])

  function toggle(id: number) {
    setSelected(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id])
  }

  async function save() {
    await createOutfit(selected, notes || undefined)
    setSelected([])
    setNotes('')
    alert('Outfit saved!')
  }

  return (
    <div className="mt-6 space-y-4">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Pick items</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map(i => (
            <button key={i.id} className={`border rounded-xl overflow-hidden text-left ${selected.includes(i.id) ? 'ring-2 ring-black' : ''}`} onClick={()=>toggle(i.id)}>
              {i.image_url ? <img src={i.image_url} className="w-full h-36 object-cover" /> : <div className="h-36 bg-gray-100 flex items-center justify-center text-sm text-gray-500">No image</div>}
              <div className="p-3">
                <div className="font-medium">{i.category}</div>
                <div className="text-sm text-gray-600">{[i.color, i.size, i.season].filter(Boolean).join(' · ')}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Notes</h2>
        <textarea className="input h-24" value={notes} onChange={e=>setNotes(e.target.value)} />
        <div className="mt-3">
          <button disabled={selected.length===0} className="btn btn-primary" onClick={save}>Save Outfit</button>
          <span className="ml-3 text-sm text-gray-600">{selected.length} selected</span>
        </div>
      </div>
    </div>
  )
}
