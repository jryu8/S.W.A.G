
import { useEffect, useState } from 'react'
import { getRecommendations, Recommendation } from '@/lib/api'

export function RecommendPage() {
  const [event, setEvent] = useState('')
  const [season, setSeason] = useState('')
  const [recs, setRecs] = useState<Recommendation[] | Recommendation | null>(null)

  async function run() {
    const r = await getRecommendations({ event: event || undefined, season: season || undefined })
    setRecs(r)
  }

  return (
    <div className="mt-6 space-y-4">
      <div className="card">
        <h2 className="text-lg font-semibold mb-3">Get recommendations</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input className="input" placeholder="Event (e.g. interview)" value={event} onChange={e=>setEvent(e.target.value)} />
          <input className="input" placeholder="Season (e.g. summer)" value={season} onChange={e=>setSeason(e.target.value)} />
        </div>
        <button className="btn btn-primary mt-3" onClick={run}>Recommend</button>
      </div>

      {recs && <div className="card">
        <h3 className="font-semibold mb-2">Results</h3>
        <pre className="text-sm whitespace-pre-wrap">{JSON.stringify(recs, null, 2)}</pre>
      </div>}
    </div>
  )
}
