
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { setAuthToken } from '@/lib/api'

type AuthState = {
  token: string | null
  setToken: (t: string | null) => void
}

export const useAuthStore = create<AuthState>()(persist(
  (set, get) => ({
    token: null,
    setToken: (t) => {
      set({ token: t })
      setAuthToken(t)
    },
  }),
  { name: 'vc-auth' }
))

// Initialize axios header on load
setAuthToken(useAuthStore.getState().token)
