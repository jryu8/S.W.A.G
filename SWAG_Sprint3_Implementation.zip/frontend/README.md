
# Virtual Closet Frontend (Vite + React + TS)

A clean frontend scaffold designed to plug into your FastAPI backend with routers:
- `users`
- `clothing`
- `outfits`
- `recommendations`

## Quick start

```bash
# 1) Install deps
npm i

# 2) Configure backend URL
cp .env.example .env
# edit .env to point to your FastAPI base (default http://localhost:8000)

# 3) Run
npm run dev
```

## Expected API (easily tweakable)

You can edit `src/lib/api.ts` if your endpoints differ.

- `POST /auth/login` (OAuth2PasswordRequestForm): returns `{ access_token, token_type }`
- `POST /users/register` with `{email, password}`
- `GET /users/me`

- `GET /clothing`
- `POST /clothing` (multipart form: `image` file and fields: `category`, `color?`, `size?`, `season?`, `tags?` (JSON string array))
- `DELETE /clothing/{id}`

- `GET /outfits`
- `POST /outfits` with `{ item_ids: number[], notes?: string }`
- `DELETE /outfits/{id}`

- `GET /recommendations?event=&season=`

If your backend uses different names (e.g., `/items` instead of `/clothing`), update the paths in `src/lib/api.ts` and field names in the forms.

## Pages

- **Login / Register**: token-based auth (stored with Zustand + persisted); `Authorization: Bearer <token>` added to axios by default.
- **Closet**: list, create (with image upload), and delete clothing items.
- **Outfit Builder**: select multiple items and save an outfit.
- **History**: view previous outfits and their items.
- **Recommendations**: fetch and display recommendation JSON.

## Styling

- Tailwind utility classes with a few small primitives (`.btn`, `.card`, `.input`).

## Customization tips

- If your backend uses `image` upload via a dedicated `/upload` endpoint, change `addClothing` accordingly.
- If tokens are returned as `{ access_token: ..., token_type: 'bearer' }`, you're set. Otherwise, adapt `login()`.
- Add error toasts, pagination, and filter controls as needed.
