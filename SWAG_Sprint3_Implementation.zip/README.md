# SWAG — Virtual Closet (Final Submission)

This package contains everything required to build and run locally without an IDE.

## Contents
- `frontend/` — your submitted frontend (extracted)
- `backend/` — your backend archive (`Backend.rar`) — extract into this folder before running
- `db/` — MySQL schema + seed
- `scripts/` — build + run scripts (Windows/macOS/Linux)
- `Makefile` — portable build targets
- `README.md` — this file

## Quick Start (no IDE)

### 1) Database (MySQL)
Open a MySQL shell and run:
```sql
SOURCE db/schema_mysql.sql;
SOURCE db/seed_mysql.sql;
```

### 2) Backend
First extract `backend/Backend.rar` **here** so this folder contains `main.py`, `routers/`, etc.
Then run:
```
scripts\run_backend.bat
```

### 3) Frontend
Run one of:
```bat
scripts\run_frontend_node.bat   # Node 'npx serve'
scripts\run_frontend_python.bat # Python http.server
```
Open the printed URL (e.g., http://localhost:3000 or http://localhost:5173).

In the app’s top-right, set **API Base URL** to:
```
http://localhost:8000
```
Click **Save**, then go to **Dashboard → Smoke Test**.

### Build scripts
- **Windows (PowerShell):**
  ```powershell
  pwsh -File scripts\build.ps1 -ApplyDb -StartServers
  ```
- **macOS/Linux:**
  ```bash
  bash scripts/build.sh --apply-db --start-servers
  ```
- **Makefile:**
  ```bash
  make db
  make backend
  make run-backend
  make run-frontend
  ```

## Notes
- Tested with MySQL 5.7/8.0 (utf8mb4, InnoDB). If you deploy to PlanetScale (no FKs), ask for a no-FK schema variant.
- If PowerShell blocks `npx`: run once `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` then retry.

